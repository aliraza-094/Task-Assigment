<?php

require 'conn.php';

 $Task_ID        = $_POST['Task_ID'];
 $Task_Name = $_POST['Task_Name'];
 $Description  = $_POST['Description'];
 $Date_created      = $_POST['Date_created'];
 $Date_Updated      = $_POST['Date_Updated'];
 
 $sql = "INSERT INTO Task (ID, Name, Description,DatCreated,DateUpdated)
VALUES ('$Task_ID','$Task_Name','$Description','$Date_created','$Date_Updated')";

if ($con->query($sql) === TRUE) {
  header('Location: index.php?i=1');
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();
?>
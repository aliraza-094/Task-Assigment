<?php

require 'conn.php';
 
 $sql = "select ID from Task";

$result = $con->query($sql)

?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="bootstrap/dist/css/bootstrap.min.css"></script>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SODING: INDIVIDUAL ASSIGNMENT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

   <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b></b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Task</b>Panel</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
    </nav>
  </header>

  <!-- =============================================== -->

  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
       
      </div>
      <!-- search form -->
       <form action="#" method="get" class="sidebar-form">
        <div class="input-group">

          <span class="input-group-btn">
               
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">TASK Operations</li>
     
      
              <li><a href="index.php"><i class="fa fa-circle-o"></i>Create Task</a></li>
            <li><a href="editTask.php"><i class="fa fa-circle-o"></i>Edit Task</a></li>
            <li><a href="deleteTask.php"><i class="fa fa-circle-o"></i>Delete Task</a></li>
            <li><a href="ListAllTasks.php"><i class="fa fa-circle-o"></i>List All Tasks</a></li>
         
       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Task
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Edit Task</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Select Task Id from dropdown to Edit Task</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="container">
                <div class="row">
                    <form role="form" action="UpdateTaskphp.php"  method="post" enctype="multipart/form-data">
                        <div class="col-lg-4">
                          <div class="well well-sm"><strong><span class="glyphicon glyphicon-asterisk"></span>Required Field</strong></div>					
                           <div class="form-group">
                                <label for="InputGender">Select Task ID</label>
								<div class="input-group">
                                <select class="form-control" name="Task_id" onchange="myfun(this.value)">
                                    <option value="">Select ID</option>
									<?php
				            while ($row = $result->fetch_row()) {
					
                                     ?>  
							    <option value='<?php echo $row[0];?>'><?php echo $row[0];?></option>
							<?php }?>
                                </select>
								  <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                               </div> 
							</div>
                                <div class="form-group">
                                    <label for="InputRoll">Task Name</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control"  id="Task_Name"  name="Task_Name" placeholder="Task Name" required>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                    </div>
                                </div>
								<div class="form-group">
                                    <label for="InputRoll">Description</label>
                                    <div class="input-group">
                                        <input type="text"  class="form-control"  id="Description"  name="Description" placeholder="Description" required>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                    </div>
                                </div>
								
                        </div>
                        </br></br></br></br></br></br></br>
                        <div class="col-lg-4">
                            <div class="form-group">
                                    <label for="InputRoll">Date Created</label>
                                    <div class="input-group">
                              <input type="date" size="16"  class="form-control"  id="Date_created"  name="Date_created" placeholder="Date Created" required>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                    </div>
                                </div>
								
								 <div class="form-group">
                                    <label for="InputRoll">Date Updated</label>
                                    <div class="input-group">
                              <input type="date" size="16"  class="form-control"  id="Date_Updated"  name="Date_Updated" placeholder="Date Updated" required>
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                    </div>
                                </div>

                            <input type="submit" name="submit" id="submit" value="Update" class="btn btn-info pull-right">
                        </div>
                    </form>

                </div>
            </div>
        </div>
<div class="container">
   <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">   
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sucess</h4>
        </div>
        <div class="modal-body">
          <p>Data Is Updated Successfully in Database </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>    
    </div>
  </div>  
</div>
        <!-- /.box-body -->
        <div class="box-footer">
     
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1
    </div>
    <strong>Copyright &copy; 2017-2018 <a href="https://adminlte.io">SODING: INDIVIDUAL ASSIGNMENT - TASK Panel</a>.</strong> All rights
    reserved.
  </footer>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="bower_components/raphael/raphael.min.js"></script>
<script src="morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="moment/min/moment.min.js"></script>
<script src="bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script>
var flag = getParameterByName('i');
if(flag==1)
{
$('#myModal').modal('show');
}
  $(document).ready(function () {
    $('.sidebar-menu').tree()
	
  })
  
  function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
function myfun(str){
	
	var RetArray;
  if (str == "") {
      //  document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
          RetArray = JSON.parse(this.responseText);//JSON.parse(
		  
		  document.getElementById("Task_Name").value = RetArray[0];
		  document.getElementById("Description").value = RetArray[1];
		  document.getElementById("Date_created").value = RetArray[2];
		  document.getElementById("Date_Updated").value = RetArray[3];
            }
        };
        xmlhttp.open("GET","editTaskphp.php?q="+str,true);
        xmlhttp.send();
    } 
}
					
</script>
</body>
</html>

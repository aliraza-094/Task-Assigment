<?php
require 'conn.php';
 
 $Task_ID        = $_POST['Task_id'];
 $Task_Name = $_POST['Task_Name'];
 $Description  = $_POST['Description'];
 $Date_created      = $_POST['Date_created'];
 $Date_Updated      = $_POST['Date_Updated'];
 
 $sql = "Update Task Set Name='$Task_Name',Description='$Description',DatCreated='$Date_created',DateUpdated='$Date_Updated' where ID='$Task_ID'";
 
if ($con->query($sql) === TRUE) {
   header('Location: editTask.php?i=1');
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();
 

?>
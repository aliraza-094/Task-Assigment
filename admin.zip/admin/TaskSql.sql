
DROP DATABASE IF EXISTS taskdb;
CREATE DATABASE taskdb;
USE taskdb;
DROP TABLE IF EXISTS Task;
 
 CREATE TABLE Task(
  ID            VARCHAR(50) NOT NULL UNIQUE,
  Name          VARCHAR(50) ,
  Description   VARCHAR(100) ,
  DatCreated    VARCHAR(50) ,
  DateUpdated   VARCHAR(50) ,
  PRIMARY KEY (ID)
 );
<?php

  echo returndata();
  
function returndata() {
	require 'conn.php';
 
$id = $_GET['q'];
 
 $sql = "select * from Task where ID='$id'";

$result = $con->query($sql);


$row = $result->fetch_row();
	
 $data[0] = $row[1];
 $data[1] = $row[2];
 $data[2] = $row[3];
 $data[3] = $row[4];

 return  json_encode($data);
         }
?>
<?php
require 'conn.php';
 
 $Task_ID        = $_POST['Task_id'];
 $Task_Name = $_POST['Task_Name'];
 $Description  = $_POST['Description'];
 $Date_created      = $_POST['Date_created'];
 $Date_Updated      = $_POST['Date_Updated'];
 
 $sql = "delete from Task where ID='$Task_ID'";
 
if ($con->query($sql) === TRUE) {
echo '<script language="javascript">';
echo 'alert("message successfully sent")';
echo '</script>';
   header('Location: deleteTask.php?i=1');
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();
 

?>